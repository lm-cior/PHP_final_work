<?php

session_start();

?>
<head>
<link rel="stylesheet" type="text/css" href="../css/buscarP.css">
                <style>

                </style>
                <script>

                    /*noSection = document.querySelector("#enviar");
                    sectionLoguin = document.querySelector("#formulario");

                    noSection.addEventListener('click', (e) =>{
                        e.preventDefault();
                        sectionLoguin.classList.remove("sinanimacion");
                        sectionLoguin.classList.add("animacion");
                    });


                    function animacionForm() {
                        document.getElementById("formulario").classList.toggle("animacion");

                    }*/

                    function prueba(){

                        let elementoActivo = document.querySelector('input[name="sizeBy"]:checked');
                        
                        if(elementoActivo) {

                            document.getElementById("añadir").href = "./" + elementoActivo.value + "/añadir";
                            document.getElementById("borrar").href = "./" + elementoActivo.value + "/borrar";
                            document.getElementById("legend").innerHTML = "Buscar " + elementoActivo.value;

                            if (elementoActivo.value == "Pisos") {

                                //alert(elementoActivo.value);
                                //document.getElementsByName("correo")[0].value="";    
                                //document.getElementsByName("correo")[0].placeholder="your message";

                                document.getElementById("correo").placeholder = "Direccion del Piso";
                                document.getElementById("nombre").placeholder = "Codigo Postal";
                                document.getElementById("enviar").name = "enviarPisos";

                            } 

                            if (elementoActivo.value == "Usuarios") {

                                //elementoActivo.value = "Usuarios";
                                //document.getElementsByName("correo")[0].value="";    
                                //document.getElementsByName("correo")[0].placeholder="your message1";

                                document.getElementById("correo").placeholder = "Correo del Usuario";
                                document.getElementById("nombre").placeholder = "Nombre del Usuario";
                                document.getElementById("enviar").name = "enviarUsuarios";
                            }
                            
                        } else {

                            alert('No hay ninún elemento activo');

                        }

                    }

                </script>
            </head>
                <body>
                    <div id="div"></div>
                    <div id="header">
                        <header>
                        <a href="../cerrarSesion.php"><h2>Hola <?php echo strtoupper($_SESSION["nombreadmin"]) ?></h2></a>
                        </header>
                    </div>
                    <div id="widjets">
                        <div id="cop">
                            <fieldset>
                                <div id="grid2">
                                    <legend>Administrando PISOS</legend>
                                </div>
                            </fieldset>
                        </div>
                        <div id="menus">
                            <div id= "menu">
                                    <div class="container1">
                                        <a href='./index.php'>
                                            <button class="button type1">
                                                <h2>Login</h2>
                                            </button>
                                        </a>
                                        <a id="añadir" href='./Pisosañadir.php'>
                                            <button class="button type3">
                                                <h2>Añadir</h2>
                                            </button>
                                        </a>
                                        <a id="borrar" href='./Pisosborrar.php'>
                                            <button class="button type3">
                                                <h2>Borrar</h2>
                                            </button>
                                        </a>
                                    </div>
                            </div>
                            <form action="./modifP.php" method="POST">
                                <div id="buscar">
                                    <?php

                                        $servername = "localhost";
                                        $username = "root";
                                        $password = "rootroot";
                                        $dbname = "inmobiliaria";

                                    // Crea conexion

                                        $conn = mysqli_connect($servername, $username, $password, $dbname);

                                    // Compruebar errores:

                                        if (!$conn) {

                                            die("Connection failed: " . mysqli_connect_error());

                                        }

                                    // Insertamos los datos del form en variables.

                                        $calle = $_REQUEST["direccion"];
                                        $cp = $_REQUEST["cp"];

                                    // Query en caso de que las dos esten vacías.

                                        if (($correo == "") && ($cp == "")) {


                                            $sql = "SELECT * FROM pisos;";

                                        }

                                    // Query en caso de que el correo esté vacío.

                                        if (($correo == "") && ($cp != "")) {

                                            $sql = "SELECT * FROM pisos WHERE cp LIKE '$cp';";

                                        }

                                    // Query en caso de que el nombre esté vacío.

                                        if (($cp == "") && ($calle != "")) {

                                            $sql = "SELECT * FROM pisos WHERE calle LIKE '$calle';";

                                        }
                                            
                                    // Query en caso de que no haya nada vacío.

                                        if (($cp != "") && ($calle != "")) {

                                            $sql = "SELECT * FROM pisos WHERE calle LIKE '$calle' AND cp LIKE '$cp';";

                                        }


                                    
                                        $result = mysqli_query($conn, $sql); 

                                    //ejecutar la select

                                        
                                        
                                        if (mysqli_num_rows($result) > 0) {

                                    // Muestra los datos fila fila
                                    

                                        ?>
                                        
                                        
                                            <div><h2>Calle</h2></div>
                                            <div><h2>Numero</h2></div>
                                            <div><h2>Piso</h2></div>
                                            <div><h2>Puerta</h2></div>
                                            <div><h2>CP</h2></div>
                                            <div><h2>Metros</h2></div>
                                            <div><h2>Zona</h2></div>
                                            <div><h2>Precio</h2></div>
                                            <div><h2>Imagen</h2></div>
                                            <div><h2>ID</h2></div>
                                            
                                        

                                        <?php while($row = mysqli_fetch_assoc($result)) { 

                                            

                                        ?>
                                            
                                            <div>
                                                <a href="./modificar">
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['calle']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['numero']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['piso']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['puerta']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['cp']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['metros']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['zona']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['precio']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <img src="../pisos/<?php echo  $row['imagen']; ?>">
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['usuario_id']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                        
                                        <?php } ?>
                                        
                                    <style>

                                        img {
                                            height: 140px;
                                            width: 170px;
                                        }
                                        
                                        .buton {
                                            background-color: white;
                                            border: none;
                                            font-family: verdana, arial, sans-serif; 
                                            font-size: 14pt; 
                                        }

                                    </style>
                                        <?php

                                        /*   ?>
                                            
                                            <table>
                                            <?php
                                            while($row = mysqli_fetch_assoc($result)) {
                                                ?>
                                                <tr>
                                                <td><b>ID </b></td> <td><?php echo  $row['usuario_id']; ?></td>
                                                <td><b>Nombre </b></td><td><?php echo $row["nombres"]; ?></td>
                                                <td><b>Correo </b></td><td><?php echo $row["correo"]; ?></td>
                                                </tr>
                                                
                                                
                                                <?php

                                            }

                                            ?>
                                            </table>
                                            <?php
                                        */

                                        } else {

                                            echo "No hay datos";

                                        }

                                        mysqli_close($conn);

                                        




    ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </body>