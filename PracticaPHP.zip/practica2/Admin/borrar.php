<?php

                                    

$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";

// Crea conexion

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Compruebar errores:

if (!$conn) {

    die("Connection failed: " . mysqli_connect_error());

}

// Insertamos los datos del form en variables.

$correo = $_REQUEST["correo"];
$nombre = $_REQUEST["nombre"];

// Query en caso de que las dos esten vacías.

if (($correo == "") && ($nombre == "")) {


    $sql = "DELETE FROM usuario;";

}

// Query en caso de que el correo esté vacío.

if (($correo == "") && ($nombre != "")) {

    $sql = "DELETE FROM usuario WHERE nombres LIKE '$nombre';";

}

// Query en caso de que el nombre esté vacío.

if (($nombre == "") && ($correo != "")) {

    $sql = "DELETE  FROM usuario WHERE correo LIKE '$correo';";

}
    
// Query en caso de que no haya nada vacío.

if (($nombre != "") && ($correo != "")) {

    $sql = "DELETE  FROM usuario WHERE correo LIKE '$correo' AND nombres LIKE '$nombre';";

}



$result = mysqli_query($conn, $sql); 

//ejecutar la select

header("location:./Usuariosborrar.php");



mysqli_close($conn);






?>