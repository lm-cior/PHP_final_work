<?php
session_start();

$conn= mysqli_connect("localhost","root","rootroot","inmobiliaria");

$calle = strip_tags(trim($_REQUEST["calle"]));
$numero = strip_tags(trim($_REQUEST["numero"]));
$piso = strip_tags(trim($_REQUEST["piso"]));
$puerta = strip_tags(trim($_REQUEST["puerta"]));
$cp = strip_tags(trim($_REQUEST["cp"]));
$metros = strip_tags(trim($_REQUEST["metros"]));
$zona = strip_tags(trim($_REQUEST["zona"]));
$precio = strip_tags(trim($_REQUEST["precio"]));


$usuario_id = $_SESSION["id_usuario"];


$check = false;


$select_id_piso="select max(Codigo_piso) from pisos";
$query2=mysqli_query($conn,$select_id_piso);
$resultado2=mysqli_fetch_array($query2);
$codigo=$resultado2["max(Codigo_piso)"]+1;

echo $codigo."<br>";
echo 'hola <br>';

if (is_uploaded_file($_FILES['imagen']['tmp_name'])) {
    $nombreDirectorio = "C:/AppServ/www/practica2/img/";
    $nombreFichero = $_FILES['imagen']['name'];
// Si ya existe un fichero con el mismo nombre, renombrarlo
    $nombreCompleto = $nombreDirectorio . $nombreFichero;
    if (is_file($nombreCompleto)) {
        $idUnico = time();
        $nombreFichero = $idUnico . "-" . $nombreFichero;
        echo "---" . $nombreFichero . "---";

    }
} else {
    echo "Error";
    $check = true;
}
if ($check == false) {
    move_uploaded_file ($_FILES['imagen']['tmp_name'], $nombreDirectorio . $nombreFichero);
    $query = "INSERT INTO pisos values(00,'$calle', $numero, $piso,'$puerta',$cp,$metros,'$zona',$precio,'$nombreFichero',1);";
    echo $query;
    
    if (mysqli_query($conn, $query)) {
        header("location:index.php");
    } else {
        header("location:Pisosañadir.php");
    }
}
?>