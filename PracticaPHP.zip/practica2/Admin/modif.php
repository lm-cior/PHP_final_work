<?php
session_start();

if(isset($_POST["boton"])){

    $id = $_POST["boton"];

    $servername = "localhost";
    $username = "root";
    $password = "rootroot";
    $dbname = "inmobiliaria";

// Crea conexion

    $conn = mysqli_connect($servername, $username, $password, $dbname);

// Comprueba:

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    } 
    
    $nombres=strtolower($_REQUEST["nombres"]);
    $sql = "SELECT usuario_id, nombres, correo FROM usuario where usuario_id like '$id'";
    $result = mysqli_query($conn, $sql);
    
//echo $sql;

    if (mysqli_num_rows($result) > 0) {

// Muestra los datos fila fila

      $row = mysqli_fetch_assoc($result);

    } else {

        echo "No hay datos";

    }



?>

<head>
<link rel="stylesheet" type="text/css" href="../css/modif.css">
                <style>
                </style>
     
            </head>
                <body>
                    <div id="div"></div>
                    <div id="header">
                        <header>
                        <a href="../cerrarSesion.php"><h2>Hola <?php echo strtoupper($_SESSION["nombreadmin"]) ?></h2></a>
                        </header>
                    </div>
                    <div id="widjets">
                        <div id="cop">
                            <fieldset>
                                <div id="grid2">
                                    <legend>Administrando USUARIOS</legend>
                                </div>
                            </fieldset>
                        </div>
                        <div id="menus">
                            <div id= "menu">
                                    <div class="container1">
                                        <a href='./index.php'>
                                            <button class="button type1">
                                                <h2>Login</h2>
                                            </button>
                                        </a>
                                        <a id="añadir" href='./Usuariosañadir.php'>
                                            <button class="button type3">
                                                <h2>Añadir</h2>
                                            </button>
                                        </a>
                                        <a id="borrar" href='./Usuariosborrar.php'>
                                            <button class="button type3">
                                                <h2>Borrar</h2>
                                            </button>
                                        </a>
                                    </div>
                            </div>
                            <div id="buscar">
                                <form action="./modif2.php" method="POST" id="formulario">
                                        <h2 class="k2kpx" id="legend">Modificar Usuarios:</h2>
                                        <input id="mid" value="<?php echo $row['usuario_id'] ?>" type="number" name="mid" size="40" readonly>
                                        <input id="mnombres" value="<?php echo $row['nombres'] ?>" type="text" name="mnombres" size="40">
                                        <input id="mcorreo" value="<?php echo $row['correo'] ?>" type="text" name="mcorreo" size="40">
                                        <input id="enviar" name="modifUser" type="submit" value="Modificar">
                                </form>
                             </div>
                        </div>
                    </div>
                </body>


<?php


 



    mysqli_close($conn);  
}
?>