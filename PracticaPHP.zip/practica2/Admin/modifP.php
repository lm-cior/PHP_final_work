<?php
session_start();

if(isset($_POST["boton"])){

    $id = $_POST["boton"];

    $servername = "localhost";
    $username = "root";
    $password = "rootroot";
    $dbname = "inmobiliaria";

// Crea conexion

    $conn = mysqli_connect($servername, $username, $password, $dbname);

// Comprueba:

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    } 
    
    $_SESSION["mid"] = $id;

    $nombres=strtolower($_REQUEST["nombres"]);
    $sql = "SELECT * FROM pisos where Codigo_piso like '$id'";
    $result = mysqli_query($conn, $sql);
    
//echo $sql;

    if (mysqli_num_rows($result) > 0) {

// Muestra los datos fila fila

      $row = mysqli_fetch_assoc($result);

    } else {

        echo "No hay datos";

    }



?>

<head>
<link rel="stylesheet" type="text/css" href="../css/modifP.css">
<style>
 
            </style>
 
        </head>
            <body>
                <div id="div"></div>
                <div id="header">
                    <header>
                    <a href="../cerrarSesion.php"><h2>Hola <?php echo strtoupper($_SESSION["nombreadmin"]) ?></h2></a>
                    </header>
                </div>
                <div id="widjets">
                    <div id="cop">
                        <fieldset>
                            <div id="grid2">
                                <legend>Administrando PISOS</legend>
                            </div>
                        </fieldset>
                    </div>
                    <div id="menus">
                        <div id= "menu">
                                <div class="container1">
                                    <a href='./index.php'>
                                        <button class="button type1">
                                            <h2>Login</h2>
                                        </button>
                                    </a>
                                    <a id="añadir" href='./Pisosañadir.php'>
                                        <button class="button type3">
                                            <h2>Añadir</h2>
                                        </button>
                                    </a>
                                    <a id="borrar" href='./Pisosborrar.php'>
                                        <button class="button type3">
                                            <h2>Borrar</h2>
                                        </button>
                                    </a>
                                </div>
                        </div>
                        <div id="buscar">
                            <form action="./modif2P.php" method="POST" id="formulario" ENCTYPE="multipart/form-data">
                                    <h2 class="k2kpx" id="legend">Modificar Piso:</h2>
                                    <input id="mcalle" value="<?php echo $row['calle'] ?>" type="text" name="calle" size="40">
                                    <input id="mnumero" value="<?php echo $row['numero'] ?>" type="text" name="numero" size="40">
                                    <input id="mpiso" value="<?php echo $row['piso'] ?>" type="text" name="piso" size="40">
                                    <input id="mpuerta" value="<?php echo $row['puerta'] ?>" type="text" name="puerta" size="40">
                                    <input id="mcp" value="<?php echo $row['cp'] ?>" type="text" name="cp" size="40">
                                    <input id="mmetros" value="<?php echo $row['metros'] ?>" type="text" name="metros" size="40">
                                    <input id="mzona" value="<?php echo $row['zona'] ?>" type="text" name="zona" size="40">
                                    <input id="mprecio" value="<?php echo $row['precio'] ?>" type="text" name="precio" size="40">
                                    <input id="mimagen" value="<?php echo $row['imagen'] ?>" type="FILE" size="80" name="imagen">
                                    <input id="menviar" name="mPiso" type="submit" value="Modificar">
                            </form>
                         </div>
                    </div>
                </div>
            </body>


<?php


 



    mysqli_close($conn);  
}
?>