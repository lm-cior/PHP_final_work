<?php

session_start();

?>
<head>
<link rel="stylesheet" type="text/css" href="../css/UsuariosBorrar.css">
                <style>
                </style>

            </head>
                <body>
                    <div id="div"></div>
                    <div id="header">
                        <header>
                        <a href="../cerrarSesion.php"><h2>Hola <?php echo strtoupper($_SESSION["nombreadmin"]) ?></h2></a>
                        </header>
                    </div>
                    <div id="widjets">
                    <div id="cop">
                            <fieldset>
                                <div id="grid2">
                                    <legend>Administrando USUARIOS</legend>
                                </div>
                            </fieldset>
                        </div>
                        <div id="menus">
                            <div id= "menu">
                                    <div class="container1">
                                        <a href='./index.php'>
                                            <button class="button type1">
                                                <h2>Login</h2>
                                            </button>
                                        </a>
                                        <a id="añadir" href='./Usuariosañadir.php'>
                                            <button class="button type3">
                                                <h2>Añadir</h2>
                                            </button>
                                        </a>
                                        <a id="borrar" href='./Usuariosborrar.php'>
                                            <button class="button type3">
                                                <h2>Borrar</h2>
                                            </button>
                                        </a>
                                    </div>
                            </div>
                            <div id="buscar">
                                <form action="./borrar.php" method="POST" id="formulario">
                                        <h2 id="legend">Borrar Usuarios:</h2>
                                        <input id="correo" placeholder="Correo del Usuario" type="text" name="correo" size="40">
                                        <input id="nombre" placeholder="Nombre del Usuario" type="text" name="nombre" size="40">
                                        <input id="enviar" name="enviarUsuarios" type="submit" value="Enviar">
                                </form>
                             </div>
                        </div>
                    </div>
                </body>