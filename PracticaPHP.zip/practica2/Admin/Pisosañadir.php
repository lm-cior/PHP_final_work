<?php
session_start();

$id = $_POST["boton"];

$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";

// Crea conexion

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Comprueba:

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
} 




?>

<head>
<link rel="stylesheet" type="text/css" href="../css/PisosAñadir.css">
            <style>

            </style>
 
        </head>
            <body>
                <div id="div"></div>
                <div id="header">
                    <header>
                    <a href="../cerrarSesion.php"><h2>Hola <?php echo strtoupper($_SESSION["nombreadmin"]) ?></h2></a>
                    </header>
                </div>
                <div id="widjets">
                    <div id="cop">
                        <fieldset>
                            <div id="grid2">
                                <legend>Administrando PISOS</legend>
                            </div>
                        </fieldset>
                    </div>
                    <div id="menus">
                        <div id= "menu">
                                <div class="container1">
                                    <a href='./index.php'>
                                        <button class="button type1">
                                            <h2>Login</h2>
                                        </button>
                                    </a>
                                    <a id="añadir" href='./Pisosañadir.php'>
                                        <button class="button type3">
                                            <h2>Añadir</h2>
                                        </button>
                                    </a>
                                    <a id="borrar" href='./Pisosborrar.php'>
                                        <button class="button type3">
                                            <h2>Borrar</h2>
                                        </button>
                                    </a>
                                </div>
                        </div>
                        <div id="buscar">
                            <form action="./añadir.php" method="POST" id="formulario" ENCTYPE="multipart/form-data">
                                    <h2 class="k2kpx" id="legend">Añadir Piso:</h2>
                                    <input id="calle" placeholder="Calle" type="text" name="calle" size="40">
                                    <input id="numero" placeholder="Numero" type="text" name="numero" size="40">
                                    <input id="piso" placeholder="Piso" type="text" name="piso" size="40">
                                    <input id="puerta" placeholder="Puerta" type="text" name="puerta" size="40">
                                    <input id="cp" placeholder="Codigo Postal" type="text" name="cp" size="40">
                                    <input id="metros" placeholder="Metros Cuadrados" type="text" name="metros" size="40">
                                    <input id="zona" placeholder="Zona" type="text" name="zona" size="40">
                                    <input id="precio" placeholder="Precio" type="text" name="precio" size="40">
                                    <input id="imagen" placeholder="Imagen" type="FILE" size="80" name="imagen">
                                    <input id="enviar" name="añPiso" type="submit" value="Añadir">
                            </form>
                         </div>
                    </div>
                </div>
            </body>



