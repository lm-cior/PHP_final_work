<?php

session_start();

?>
<head>
<link rel="stylesheet" type="text/css" href="../css/buscar.css">
                <script>

                    /*noSection = document.querySelector("#enviar");
                    sectionLoguin = document.querySelector("#formulario");

                    noSection.addEventListener('click', (e) =>{
                        e.preventDefault();
                        sectionLoguin.classList.remove("sinanimacion");
                        sectionLoguin.classList.add("animacion");
                    });


                    function animacionForm() {
                        document.getElementById("formulario").classList.toggle("animacion");

                    }*/

                    function prueba(){

                        let elementoActivo = document.querySelector('input[name="sizeBy"]:checked');
                        
                        if(elementoActivo) {

                            document.getElementById("añadir").href = "./" + elementoActivo.value + "/añadir";
                            document.getElementById("borrar").href = "./" + elementoActivo.value + "/borrar";
                            document.getElementById("legend").innerHTML = "Buscar " + elementoActivo.value;

                            if (elementoActivo.value == "Pisos") {

                                //alert(elementoActivo.value);
                                //document.getElementsByName("correo")[0].value="";    
                                //document.getElementsByName("correo")[0].placeholder="your message";

                                document.getElementById("correo").placeholder = "Direccion del Piso";
                                document.getElementById("nombre").placeholder = "Codigo Postal";
                                document.getElementById("enviar").name = "enviarPisos";

                            } 

                            if (elementoActivo.value == "Usuarios") {

                                //elementoActivo.value = "Usuarios";
                                //document.getElementsByName("correo")[0].value="";    
                                //document.getElementsByName("correo")[0].placeholder="your message1";

                                document.getElementById("correo").placeholder = "Correo del Usuario";
                                document.getElementById("nombre").placeholder = "Nombre del Usuario";
                                document.getElementById("enviar").name = "enviarUsuarios";
                            }
                            
                        } else {

                            alert('No hay ninún elemento activo');

                        }

                    }

                </script>
            </head>
                <body>
                    <div id="div"></div>
                    <div id="header">
                        <header>
                        <a href="../cerrarSesion.php"><h2>Hola <?php echo strtoupper($_SESSION["nombreadmin"]) ?></h2></a>
                        </header>
                    </div>
                    <div id="widjets">
                        <div id="cop">
                            <fieldset>
                                <div id="grid2">
                                    <legend>Administrando USUARIOS</legend>
                                </div>
                            </fieldset>
                        </div>
                        <div id="menus">
                            <div id= "menu">
                                    <div class="container1">
                                        <a href='./index.php'>
                                            <button class="button type1">
                                                <h2>Login</h2>
                                            </button>
                                        </a>
                                        <a id="añadir" href='./Usuariosañadir.php'>
                                            <button class="button type3">
                                                <h2>Añadir</h2>
                                            </button>
                                        </a>
                                        <a id="borrar" href='./Usuariosborrar.php'>
                                            <button class="button type3">
                                                <h2>Borrar</h2>
                                            </button>
                                        </a>
                                    </div>
                            </div>
                            <form action="./modif.php" method="POST">
                                <div id="buscar">
                                    <?php

                                    

                                        $servername = "localhost";
                                        $username = "root";
                                        $password = "rootroot";
                                        $dbname = "inmobiliaria";

                                    // Crea conexion

                                        $conn = mysqli_connect($servername, $username, $password, $dbname);

                                    // Compruebar errores:

                                        if (!$conn) {

                                            die("Connection failed: " . mysqli_connect_error());

                                        }

                                    // Insertamos los datos del form en variables.

                                        $correo = $_REQUEST["correo"];
                                        $nombre = $_REQUEST["nombre"];

                                    // Query en caso de que las dos esten vacías.

                                        if (($correo == "") && ($nombre == "")) {


                                            $sql = "SELECT usuario_id, nombres, correo, clave FROM usuario;";

                                        }

                                    // Query en caso de que el correo esté vacío.

                                        if (($correo == "") && ($nombre != "")) {

                                            $sql = "SELECT usuario_id, nombres, correo, clave FROM usuario WHERE nombres LIKE '$nombre';";

                                        }

                                    // Query en caso de que el nombre esté vacío.

                                        if (($nombre == "") && ($correo != "")) {

                                            $sql = "SELECT usuario_id, nombres, correo, clave FROM usuario WHERE correo LIKE '$correo';";

                                        }
                                            
                                    // Query en caso de que no haya nada vacío.

                                        if (($nombre != "") && ($correo != "")) {

                                            $sql = "SELECT usuario_id, nombres, correo, clave FROM usuario WHERE correo LIKE '$correo' AND nombres LIKE '$nombre';";

                                        }


                                    
                                        $result = mysqli_query($conn, $sql); 

                                    //ejecutar la select

                                        
                                        
                                        if (mysqli_num_rows($result) > 0) {

                                    // Muestra los datos fila fila
                                    

                                        ?>
                                        
                                        
                                            <div><h2>ID</h2></div>
                                            <div><h2>Nombre</h2></div>
                                            <div><h2>E-Mail</h2></div>
                                        

                                        <?php while($row = mysqli_fetch_assoc($result)) { 

                                            

                                        ?>
                                            
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['usuario_id']; ?>">
                                                        <?php echo  $row['usuario_id']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['usuario_id']; ?>">
                                                        <?php echo  $row['nombres']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['usuario_id']; ?>">
                                                        <?php echo  $row['correo']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                        
                                        <?php }



                                        } else {

                                            echo "No hay datos";

                                        }

                                        mysqli_close($conn);

                                        




    ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </body>