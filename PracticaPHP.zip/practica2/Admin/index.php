<?php

session_start();

?>
<head>
                <style>
                </style>
                <link rel="stylesheet" type="text/css" href="../css/indexA.css">
                <script>

                    function prueba(){

                        let elementoActivo = document.querySelector('input[name="sizeBy"]:checked');
                        
                        if(elementoActivo) {

                            document.getElementById("añadir").href = "./" + elementoActivo.value + "añadir.php";
                            document.getElementById("borrar").href = "./" + elementoActivo.value + "borrar.php";
                            document.getElementById("legend").innerHTML = "Buscar " + elementoActivo.value + ":";

                            if (elementoActivo.value == "Pisos") {

                                //alert(elementoActivo.value);
                                //document.getElementsByName("correo")[0].value="";    
                                //document.getElementsByName("correo")[0].placeholder="your message";

                                document.getElementById("correo").placeholder = "Direccion del Piso";
                                document.getElementById("nombre").placeholder = "Codigo Postal";
                                document.getElementById("enviar").name = "enviarPisos";
                                document.getElementById("formulario").action = "./buscarP.php"

                            } 

                            if (elementoActivo.value == "Usuarios") {

                                //elementoActivo.value = "Usuarios";
                                //document.getElementsByName("correo")[0].value="";    
                                //document.getElementsByName("correo")[0].placeholder="your message1";

                                document.getElementById("correo").placeholder = "Correo del Usuario";
                                document.getElementById("nombre").placeholder = "Nombre del Usuario";
                                document.getElementById("enviar").name = "enviarUsuarios";
                                document.getElementById("formulario").action = "./buscar.php"
                            }
                            
                        } else {

                            alert('No hay ninún elemento activo');

                        }

                    }

                </script>
            </head>
                <body>
                    <div id="div"></div>
                    <div id="header">
                        <header>
                        <a href="../cerrarSesion.php"><h2>Hola <?php echo strtoupper($_SESSION["nombreadmin"]) ?></h2></a>
                        </header>
                    </div>
                    <div id="widjets">
                        <div id="cop">
                            <fieldset>
                                <div id="grid2">
                                    <legend>¿Que quieres administrar?</legend>
                                    <div class="toggle">
                                        <div id="grid">
                                            <input type="radio" onclick="prueba()" name="sizeBy" value="Usuarios" id="sizeWeight" checked="checked" />
                                            <label for="sizeWeight">Usuarios</label>
                                            <input type="radio" onclick="prueba()" name="sizeBy" value="Pisos" id="sizeDimensions"/>
                                            <label for="sizeDimensions">Pisos</label>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </div>
                        <div id="menus">
                            <div id= "menu">
                                    <div class="container1">
                                        <a href='./index.php'>
                                            <button class="button type1">
                                                <h2>Login</h2>
                                            </button>
                                        </a>
                                        <a id="añadir" href='./Usuariosañadir.php'>
                                            <button class="button type3">
                                                <h2>Añadir</h2>
                                            </button>
                                        </a>
                                        <a id="borrar" href='./Usuariosborrar.php'>
                                            <button class="button type3">
                                                <h2>Borrar</h2>
                                            </button>
                                        </a>
                                    </div>
                            </div>
                            <div id="buscar">
                                <form action="./buscar.php" method="POST" id="formulario">
                                        <h2 id="legend">Buscar Usuarios:</h2>
                                        <input id="correo" placeholder="Correo del Usuario" type="text" name="correo" size="40">
                                        <input id="nombre" placeholder="Nombre del Usuario" type="text" name="nombre" size="40">
                                        <input id="enviar" name="enviarUsuarios" type="submit" value="Enviar">
                                </form>
                             </div>
                        </div>
                    </div>
                </body>