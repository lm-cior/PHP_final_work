<?php 

$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";

// Crea conexion

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Compruebar errores:

if (!$conn) {

    die("Connection failed: " . mysqli_connect_error());

}

// Insertamos los datos del form en variables.

$calle = $_REQUEST["direccion"];
$cp = $_REQUEST["cp"];

// Query en caso de que las dos esten vacías.

if (($correo == "") && ($cp == "")) {


    $sql = "SELECT * FROM pisos;";

}

// Query en caso de que el correo esté vacío.

if (($correo == "") && ($cp != "")) {

    $sql = "SELECT * FROM pisos WHERE cp LIKE '$cp';";

}

// Query en caso de que el nombre esté vacío.

if (($cp == "") && ($calle != "")) {

    $sql = "SELECT * FROM pisos WHERE calle LIKE '$calle';";

}
    
// Query en caso de que no haya nada vacío.

if (($cp != "") && ($calle != "")) {

    $sql = "SELECT * FROM pisos WHERE calle LIKE '$calle' AND cp LIKE '$cp';";

}



$result = mysqli_query($conn, $sql); 

?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/index.css">
    </head>
        <body>
            
            <div class="menu">
                <div class="label">Menu</div>
                <div class="spacer"></div>
                <a id="link" href="index.php"><div class="item"><span>Pisos</span></div></a>
                <a id="link" href="#"><div  id="alerta1" class="item"><span>Chalets</span></div></a>
                <a id="link" href="loguin.php"><div class="item"><span>Login</span></div></a>
                <a id="link" href="registro.php"><div class="item"><span>Registrarse</span></div></a>
                <a id="link" href="#"><div class="item" id="alerta"><span>Ajustes</span></div></a>
            </div>
<div id="container">
    
    <input hidden type="radio" name="carousel-control" id="button_a" checked/>
    <input hidden type="radio" name="carousel-control" id="button_b"/>
    <input hidden type="radio" name="carousel-control" id="button_c"/>
    <input hidden type="radio" name="carousel-control" id="button_d"/>            
            
    
    <div id="carousel">
        <div class="p-wrapper">
                    
            <section class="panel_a">
                
                <img src="./pisos/160223.webp"/>
            </section>
            <section class="panel_b">
                
                <img src="./pisos/170223.jpg"/>
            </section>
            <section class="panel_c">
                
                <img src="./pisos/182023.jpg"/>
            </section>
            <section class="panel_d">
                
                <img src="./pisos/190223.jpg"/>
            </section>
                    
        </div> <!-- // .p-wrapper -->
    </div> <!-- // #carousel -->            
            
    
    <div id="navigation">
        <label for="button_a" class="label_a"> <span>a</span> </label>
        <label for="button_b" class="label_b"> <span>b</span> </label>
        <label for="button_c" class="label_c"> <span>c</span> </label>
        <label for="button_d" class="label_d"> <span>d</span> </label>
    </div> <!-- // #navigation -->               
            
    
</div> <!-- // #container -->

<form method="POST">
                                <div id="buscar">
<?php


                                    //ejecutar la select

                                        
                                        
                                        if (mysqli_num_rows($result) > 0) {

                                    // Muestra los datos fila fila
                                    

                                        ?>
                                        
                                        
                                            <div><h2>Calle</h2></div>
                                            <div><h2>Numero</h2></div>
                                            <div><h2>Piso</h2></div>
                                            <div><h2>Puerta</h2></div>
                                            
                                            <div><h2>Metros</h2></div>
                                            <div><h2>Zona</h2></div>
                                            <div><h2>Precio</h2></div>
                                            <div><h2>Imagen</h2></div>
                                            
                                            
                                        

                                        <?php while($row = mysqli_fetch_assoc($result)) { 

                                            

                                        ?>
                                            
                                            <div>
                                                <a>
                                                    <button class="buton alerta2" name="boton" value="<?php echo  $row['Codigo_piso']; ?>"  >
                                                        <?php echo  $row['calle']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button  class="buton alerta2" name="boton" value="<?php echo  $row['Codigo_piso']; ?>"  >
                                                        <?php echo  $row['numero']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button  class="buton alerta2" name="boton" value="<?php echo  $row['Codigo_piso']; ?>"  >
                                                        <?php echo  $row['piso']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button  class="buton alerta2" name="boton" value="<?php echo  $row['Codigo_piso']; ?>"  >
                                                        <?php echo  $row['puerta']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            
                                            <div>
                                                <a>
                                                    <button  class="buton alerta2" name="boton" value="<?php echo  $row['Codigo_piso']; ?>"  >
                                                        <?php echo  $row['metros']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button  class="buton alerta2" name="boton" value="<?php echo  $row['Codigo_piso']; ?>"  >
                                                        <?php echo  $row['zona']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button  class="buton alerta2" name="boton" value="<?php echo  $row['Codigo_piso']; ?>"  >
                                                        <?php echo  $row['precio']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button  class="buton alerta2" name="boton" value="<?php echo  $row['Codigo_piso']; ?>"  >
                                                        <img id="img1" src="./pisos/<?php echo  $row['imagen']; ?>">
                                                    </button>
                                                </a>
                                            </div>
                                            
                                        
                                        <?php } 

                                        } else {

                                            echo "No hay datos";

                                        }

                                        mysqli_close($conn);
?>


            <script>
                document.getElementById("alerta").addEventListener("click", myFunction);

                function myFunction() {
                    alert("Debes registrarte primero.");
                }
                document.getElementById("alerta1").addEventListener("click", myFunction1);

                function myFunction1() {
                    alert("Ahora mismo no hay Chalets disponibles.");
                }
                document.getElementsByClassName("buton").addEventListener("click", myFunction2);

                function myFunction2() {
                    alert("Inicia Sesión para poder acceder a la compra de pisos.");
                }
            </script>
        </body>
</html>