<?php

session_start();

if(isset($_REQUEST["enviar"])) {

    $servername = "localhost";
    $username = "root";
    $password = "rootroot";
    $dbname = "inmobiliaria";

// Crear la Conexión
    $conn = mysqli_connect($servername, $username, $password, $dbname);

// Comprueba la conexion

    if (!$conn) {

        die("Connection failed: " . mysqli_connect_error());

    }

    $correo=trim(strtolower($_REQUEST["correo"]));
    $passwd=trim($_REQUEST["passwd"]);

    $password=password_hash("$passwd", PASSWORD_DEFAULT);

// Comando SQL de insertar

    $sql = "SELECT usuario_id, nombres, correo, clave, tipo_usuario FROM usuario WHERE correo = '$correo'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $password=$row["clave"];

    if (($row["tipo_usuario"] == "administrador") && (password_verify($passwd, $password))) {

        $_SESSION["id"]=$row["usuario_id"];
        $_SESSION["nombreadmin"]=$row["nombres"];

        header("location:./Admin/index.php");

    } 
    elseif (($row["tipo_usuario"] == "vendedor") && (password_verify($passwd, $password))) {

        $_SESSION["id"]=$row["usuario_id"];
        $_SESSION["nombreadmin"]=$row["nombres"];

        header("location:./Vendedor/index.php");

    }
    elseif (($row["tipo_usuario"] == "cliente") && (password_verify($passwd, $password))) {

        $_SESSION["id"]=$row["usuario_id"];
        $_SESSION["nombreadmin"]=$row["nombres"];

        header("location:./Cliente/index.php");

    }
    else {
        ?>
        <link rel="stylesheet" type="text/css" href="./css/login.css">
            
            <body>
                <form action="loguin.php" method="POST"  onsubmit="return validacion()">
                    <div>
                        <table>
                            <tr>
                                <h1>INICIO DE SESIÓN</h1>
                            </tr>
                            <tr>
                                <td><input id="usuario" placeholder="Correo" type="text" name="correo" size="40"></td>
                            </tr>
                            <tr>
                                <td><input id="passwd" placeholder="Contraseña" type="password" name="passwd" size="40"></td>
                            </tr>
                            <tr><td><input id="enviar" name="enviar" type="submit" value="Enviar"></td></tr>
                            <tr>
                                <td><h2> o </h2></td>
                            </tr>
                            <tr>
                                <td><input id="reset" name="registro" type="submit" value="Regístrese"></td>
                            </tr>
                        </table>
                    </div>
                </form>
            </body>
            <script>
                alert("Correo o Contaseña incorrecto, pruebe otra vez.");
                function validacion(){
                    var correo = document.getElementById("usuario").value;
                    var contraseña = document.getElementById("passwd").value;
                    if (correo.length < 0 ){
                        alert("Correo o contraseña incorrecto")
                        event.preventDefault();
                    }
                    if (contraseña.length < 0 ){
                        alert("Correo o contraseña incorrecto")
                        event.preventDefault();
                    }
                }
            </script>
        <?php
    }

    mysqli_close($conn);

/*HTML Y CSS DEL LOGIN*/
} elseif(isset($_POST["registro"])) {

    header("location:./registro.php");

} else {
    ?>
    <link rel="stylesheet" type="text/css" href="./css/login.css">
        
        <body>
            <form action="loguin.php" method="POST" onsubmit="return validacion()">
                <div>
                    <table>
                        <tr>
                            <h1>INICIO DE SESIÓN</h1>
                        </tr>
                        <tr>
                            <td><input id="usuario" placeholder="Correo" type="text" name="correo" size="40"></td>
                        </tr>
                        <tr>
                            <td><input id="passwd" placeholder="Contraseña" type="password" name="passwd" size="40"></td>
                        </tr>
                        <tr><td><input id="enviar" name="enviar" type="submit" value="Enviar"></td></tr>
                        <tr>
                            <td><h2> o </h2></td>
                        </tr>
                        <tr>
                            <td><input id="reset" name="registro" type="submit" value="Regístrese"></td>
                        </tr>
                    </table>
                </div>
            </form>
        </body>
        <script>

                function validacion(){
                    var correo = document.getElementById("usuario").value;
                    var contraseña = document.getElementById("passwd").value;
                    if (correo.length < 0 ){
                        alert("Correo o contraseña incorrecto")
                        event.preventDefault();
                    }
                    if (contraseña.length < 0 ){
                        alert("Correo o contraseña incorrecto")
                        event.preventDefault();
                    }
                }
        </script>
    <?php

}
?>