<?php

$id = $_POST["boton"];

$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";

// Crea conexion

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Comprueba:

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
} 




?>

<head>
    <link rel="stylesheet" type="text/css" href="./css/registro.css">
    <link rel="stylesheet" type="text/css" href="./css/radios.css">
        </head>
            <body>
                <div id="div"></div>
                <div id="header">
                    <header>
                        <a href="./loguin.php"><h2>Volver al Loguin</h2></a>
                    </header>
                </div>
                <div id="widjets">
                    <div id="cop">
                        <fieldset>
                            <div id="grid2">
                                <legend>Bienvenido a Zanny X Orochi</legend>
                            </div>
                        </fieldset>
                    </div>
                        <div id="buscar">
                            <form action="./registro.php" method="POST" id="formulario">
                                    <h2 class="k2kpx" id="legend">Inserta tus datos:</h2>

                                    <input id="anombres" placeholder="Nombre de Usuario" type="text" name="anombres" size="40" required>
                                    <input id="acorreo" placeholder="Correo Electrónico" type="text" name="acorreo" size="40" required>
                                    <input id="acontraseña" placeholder="Contraseña" type="text" name="acontraseña" size="40" required>

                                    <label class="container3">Vendedor
                                        <input type="radio" checked="checked" name="radio" value="vendedor">
                                        <span class="checkmark"></span>
                                    </label>
                                    <label class="container3">Cliente
                                        <input type="radio" name="radio" value="cliente">
                                        <span class="checkmark"></span>
                                    </label>

                                    <input id="enviar" name="añUser" type="submit" value="Añadir">
                            </form>
                         </div>
                    </div>
                </div>
            </body>


<?php

if(isset($_POST["añUser"])){

    $nombre=trim(strtolower($_POST["anombres"]));
    $correo=trim(strtolower($_POST["acorreo"]));
    $tipo=$_POST["radio"];
    $passwd=trim($_POST["acontraseña"]);
    $password=password_hash("$passwd", PASSWORD_DEFAULT);

// Comando SQL de insertar

    $sql = "INSERT INTO usuario (usuario_id, nombres, correo, clave, tipo_usuario) VALUES
            (00, '$nombre', '$correo', '$password', '$tipo')";

//Ejecuta el insert y controla el error.

    if (mysqli_query($conn, $sql)) {

        header("location:./loguin.php");

    } else {

        echo "Error: " . $sql . "<br>" . mysqli_error($conn);

    }
    mysqli_close($conn);

}

?>