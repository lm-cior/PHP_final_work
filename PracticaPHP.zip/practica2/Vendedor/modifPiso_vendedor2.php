<?php 
session_start();

    if(isset($_REQUEST["mPiso"])){

        $servername = "localhost";
        $username = "root";
        $password = "rootroot";
        $dbname = "inmobiliaria";

    // Crea conexion

        $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Comprueba:

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        } 

        $mid =  $_SESSION["mid"];

        $mcalle = strip_tags(trim($_REQUEST["calle"]));
        $mnumero = strip_tags(trim($_REQUEST["numero"]));
        $mpiso = strip_tags(trim($_REQUEST["piso"]));
        $mpuerta = strip_tags(trim($_REQUEST["puerta"]));
        $mcp = strip_tags(trim($_REQUEST["cp"]));
        $mmetros = strip_tags(trim($_REQUEST["metros"]));
        $mzona = strip_tags(trim($_REQUEST["zona"]));
        $mprecio = strip_tags(trim($_REQUEST["precio"]));


        $sql = "UPDATE pisos SET calle='$mcalle', numero='$mnumero', piso='$mpiso', puerta='$mpuerta', cp='$mcp', metros='$mnumero', zona='$mmetros', precio='$mprecio' WHERE Codigo_piso=$mid;";
        echo "<BR>$sql<BR>";

    /*UPDATE usuario SET nombres='jota', correo='jota@gmail.com' WHERE usuario_id=2;*/
            
        if (mysqli_query($conn, $sql)) {

            echo "Record updated successfully";
            header("location:./listarPiso_vendedor.php");
            $_SESSION["mbusc"] = "";


        } else {

            echo "Error updating record: " . mysqli_error($conn);

        }
        mysqli_close($conn);
            

    } else {

        echo "hola";   

    }

?>