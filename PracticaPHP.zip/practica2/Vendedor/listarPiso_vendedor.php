<?php

session_start();
$id=$_SESSION["id"];

?>
<head>
<link rel="stylesheet" type="text/css" href="../css/buscarP.css">
                <style>

                </style>
                <script>



                </script>
            </head>
                <body>
                    <div id="div"></div>
                    <div id="header">
                        <header>
                        <a href="../cerrarSesion.php"><h2>Hola <?php echo strtoupper($_SESSION["nombreadmin"]) ?></h2></a>
                        </header>
                    </div>
                    <div id="widjets">
                        <div id="cop">
                            <fieldset>
                                <div id="grid2">
                                    <legend>Administrando PISOS</legend>
                                </div>
                            </fieldset>
                        </div>
                        <div id="menus">
                            <div id= "menu">
                                <div class="container1">
                                    <a href='./listarPiso_vendedor.php'>
                                        <button class="button type1">
                                            <h2>Inicio</h2>
                                        </button>
                                    </a>
                                    <a id="añadir" href='./añadirPiso_vendedor.php'>
                                        <button class="button type3">
                                            <h2>Añadir</h2>
                                        </button>
                                    </a>
                                    <a id="borrar" href='./borrarPiso_vendedor.php'>
                                        <button class="button type3">
                                            <h2>Borrar</h2>
                                        </button>
                                    </a>
                                </div>
                            </div>
                            <form action="./modifPiso_vendedor.php" method="POST">
                                <div id="buscar">
                                    <?php

                                        $servername = "localhost";
                                        $username = "root";
                                        $password = "rootroot";
                                        $dbname = "inmobiliaria";

                                    // Crea conexion

                                        $conn = mysqli_connect($servername, $username, $password, $dbname);

                                    // Compruebar errores:

                                        if (!$conn) {

                                            die("Connection failed: " . mysqli_connect_error());

                                        }

                                    // Insertamos los datos del form en variables.



                                    // Query en caso de que las dos esten vacías.


                                            $sql = "SELECT * FROM pisos WHERE usuario_id=$id;";



                                    
                                        $result = mysqli_query($conn, $sql); 

                                    //ejecutar la select

                                        
                                        
                                        if (mysqli_num_rows($result) > 0) {

                                    // Muestra los datos fila fila
                                    

                                        ?>
                                        
                                        
                                            <div><h2>Calle</h2></div>
                                            <div><h2>Numero</h2></div>
                                            <div><h2>Piso</h2></div>
                                            <div><h2>Puerta</h2></div>
                                            <div><h2>CP</h2></div>
                                            <div><h2>Metros</h2></div>
                                            <div><h2>Zona</h2></div>
                                            <div><h2>Precio</h2></div>
                                            <div><h2>Imagen</h2></div>
                                            <div><h2>ID</h2></div>
                                            
                                        

                                        <?php while($row = mysqli_fetch_assoc($result)) { 

                                            

                                        ?>
                                            
                                            <div>
                                                <a href="#">
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['calle']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['numero']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['piso']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['puerta']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['cp']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['metros']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['zona']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['precio']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <img src="../pisos/<?php echo  $row['imagen']; ?>">
                                                    </button>
                                                </a>
                                            </div>
                                            <div>
                                                <a>
                                                    <button class="buton" name="boton" value="<?php echo  $row['Codigo_piso']; ?>">
                                                        <?php echo  $row['usuario_id']; ?>
                                                    </button>
                                                </a>
                                            </div>
                                        
                                        <?php } ?>
                                        
                                    <style>

                                        img {
                                            height: 140px;
                                            width: 170px;
                                        }
                                        
                                        .buton {
                                            background-color: white;
                                            border: none;
                                            font-family: verdana, arial, sans-serif; 
                                            font-size: 14pt; 
                                        }

                                    </style>
                                        <?php

                                        /*   ?>
                                            
                                            <table>
                                            <?php
                                            while($row = mysqli_fetch_assoc($result)) {
                                                ?>
                                                <tr>
                                                <td><b>ID </b></td> <td><?php echo  $row['usuario_id']; ?></td>
                                                <td><b>Nombre </b></td><td><?php echo $row["nombres"]; ?></td>
                                                <td><b>Correo </b></td><td><?php echo $row["correo"]; ?></td>
                                                </tr>
                                                
                                                
                                                <?php

                                            }

                                            ?>
                                            </table>
                                            <?php
                                        */

                                        } else {

                                            echo "No hay datos";

                                        }

                                        mysqli_close($conn);

                                        




    ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </body>