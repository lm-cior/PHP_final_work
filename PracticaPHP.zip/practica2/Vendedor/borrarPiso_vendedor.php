<?php

session_start();

?>
<head>
<link rel="stylesheet" type="text/css" href="../css/PisosBorrar.css">
                <style>
                </style>

            </head>
                <body>
                    <div id="div"></div>
                    <div id="header">
                        <header>
                        <a href="../cerrarSesion.php"><h2>Hola <?php echo strtoupper($_SESSION["nombreadmin"]) ?></h2></a>
                        </header>
                    </div>
                    <div id="widjets">
                    <div id="cop">
                            <fieldset>
                                <div id="grid2">
                                    <legend>Administrando PISOS</legend>
                                </div>
                            </fieldset>
                        </div>
                        <div id="menus">
                            <div id= "menu">
                            <div class="container1">
                                    <a href='./listarPiso_vendedor.php'>
                                        <button class="button type1">
                                            <h2>Inicio</h2>
                                        </button>
                                    </a>
                                    <a id="añadir" href='./añadirPiso_vendedor.php'>
                                        <button class="button type3">
                                            <h2>Añadir</h2>
                                        </button>
                                    </a>
                                    <a id="borrar" href='./borrarPiso_vendedor.php'>
                                        <button class="button type3">
                                            <h2>Borrar</h2>
                                        </button>
                                    </a>
                                </div>
                            </div>
                            <div id="buscar">
                                <form action="./borrarPiso_vendedor2.php" method="POST" id="formulario">
                                        <h2 id="legend">Borrar Pisos:</h2>
                                        <input id="direccion" placeholder="Direccion del Piso" type="text" name="direccion" size="40">
                                        <input id="cp" placeholder="Codigo Postal" type="text" name="cp" size="40">
                                        <input id="enviar" name="enviarPisos" type="submit" value="Enviar">
                                </form>
                             </div>
                        </div>
                    </div>
                </body>