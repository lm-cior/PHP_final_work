<?php

session_start();

?>
<head>
                <style>
                    body {
                        font-family: verdana, arial, sans-serif; 
                        font-size: 12pt; 
                        background-image: url(../OIP.jpg);  
                        background-position: bottom center;
                        background-repeat: no-repeat;
                        background-size: cover;
                        padding: 10px;
                    }
                    header {
                        display: grid;
                        position: fixed;
                        height: 100px;
                    }
                    #header {
                        height: 100px;
                        width: 100%;
                        
                    }
                    div {
                        display: grid;
                        
                    }
                    #widjets{
                        height: auto;
                        
                    }
                    #wid1{
                        height: auto;
                        text-align: center;
                        background-color: white;
                        width: 600px;
                        display: grid; 
                        justify-items: center;
                        border-radius: 15px;
                        padding: 20px;
                        grid-template-columns: repeat(3, auto);
                    
                    }

                
                    @import url("https://fonts.googleapis.com/css?family=Open+Sans:400,600");
                    /* VARS */
                    /* MIXINS */
                    /* STYLE THE HTML ELEMENTS (INCLUDES RESETS FOR THE DEFAULT FIELDSET AND LEGEND STYLES) */


                    fieldset {
                        margin: 0;
                        padding: 2rem;
                        box-sizing: border-box;
                        display: block;
                        border: none;
                        border: solid 1px #CCC;
                        min-width: 0;
                        background-color: #FFF;
                    }
                    fieldset legend {
                        margin: 0 0 1.5rem;
                        padding: 0;
                        width: 100%;
                        float: left;
                        display: table;
                        font-size: 1.5rem;
                        line-height: 140%;
                        font-weight: 600;
                        color: #333;
                    }
                    fieldset legend + * {
                        clear: both;
                    }



                    /* TOGGLE STYLING */
                    .toggle {
                        margin: 0 0 1.5rem;
                        box-sizing: border-box;
                        font-size: 0;
                        display: flex;
                        flex-flow: row nowrap;
                        justify-content: flex-start;
                        align-items: stretch;
                    }
                    .toggle input {
                        width: 0;
                        height: 0;
                        position: absolute;
                        left: -9999px;
                    }
                    .toggle input + label {
                        margin: 0;
                        padding: 0.75rem 2rem;
                        box-sizing: border-box;
                        position: relative;
                        display: inline-block;
                        border: solid 1px #DDD;
                        background-color: #FFF;
                        font-size: 1.25rem;
                        line-height: 140%;
                        font-weight: 600;
                        text-align: center;
                        box-shadow: 0 0 0 rgba(255, 255, 255, 0);
                        transition: border-color 0.15s ease-out, color 0.25s ease-out, background-color 0.15s ease-out, box-shadow 0.15s ease-out;
                        /* ADD THESE PROPERTIES TO SWITCH FROM AUTO WIDTH TO FULL WIDTH */
                        /*flex: 0 0 50%; display: flex; justify-content: center; align-items: center;*/
                    /* ----- */
                    }
                    .toggle input + label:first-of-type {
                        border-radius: 6px 0 0 6px;
                        border-right: none;
                    }
                    .toggle input + label:last-of-type {
                        border-radius: 0 6px 6px 0;
                        border-left: none;
                    }
                    .toggle input:hover + label {
                        border-color: #213140;
                    }
                    .toggle input:checked + label {
                        background-color: #eaa04b;
                        color: #FFF;
                        box-shadow: 0 0 10px rgba(102, 179, 251, 0.5);
                        border-color: #eaa04b;
                        z-index: 1;
                    }
                    .toggle input:focus + label {
                        outline: dotted 1px #CCC;
                        outline-offset: 0.45rem;
                    }
                    @media (max-width: 800px) {
                    /*.toggle input + label {
                        padding: 0.75rem 0.25rem;
                        flex: 0 0 50%;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                    }*/
                    }

                    /* STYLING FOR THE STATUS HELPER TEXT FOR THE DEMO */
                    .status {
                        margin: 0;
                        font-size: 1rem;
                        font-weight: 400;
                    }
                    .status span {
                        font-weight: 600;
                        color: #B6985A;
                    }
                    .status span:first-of-type {
                        display: inline;
                    }
                    .status span:last-of-type {
                        display: none;
                    }
                    @media (max-width: 800px) {
                    .status span:first-of-type {
                        display: none;
                    }
                    .status span:last-of-type {
                        display: inline;
                    }
                    }

                     @import url("https://fonts.googleapis.com/css?family=Raleway");


                        .button {
                        position: relative;
                        padding: 1em 1.5em;
                        border: none;
                        background-color: transparent;
                        cursor: pointer;
                        outline: none;
                        font-size: 18px;
                        margin: 1em 0.8em;
                        }
                        .button.type1 {
                        color: #566473;
                        }
                        .button.type1.type1::after, .button.type1.type1::before {
                        content: "";
                        display: block;
                        position: absolute;
                        width: 20%;
                        height: 20%;
                        border: 2px solid;
                        transition: all 0.6s ease;
                        border-radius: 2px;
                        }
                        .button.type1.type1::after {
                        bottom: 0;
                        right: 0;
                        border-top-color: transparent;
                        border-left-color: transparent;
                        border-bottom-color: #566473;
                        border-right-color: #566473;
                        }
                        .button.type1.type1::before {
                        top: 0;
                        left: 0;
                        border-bottom-color: transparent;
                        border-right-color: transparent;
                        border-top-color: #566473;
                        border-left-color: #566473;
                        }
                        .button.type1.type1:hover:after, .button.type1.type1:hover:before {
                        width: 100%;
                        height: 100%;
                        }
                        .button.type2 {
                        color: #566473;
                        }
                        .button.type2.type2:after, .button.type2.type2:before {
                        content: "";
                        display: block;
                        position: absolute;
                        top: 100%;
                        left: 0;
                        width: 100%;
                        height: 2px;
                        background-color: #16a085;
                        transition: all 0.3s ease;
                        transform: scale(0.85);
                        }
                        .button.type2.type2:hover:before {
                        top: 0;
                        transform: scale(1);
                        }
                        .button.type2.type2:hover:after {
                        transform: scale(1);
                        }
                        .button.type3 {
                        color: #435a6b;
                        }
                        .button.type3.type3::after, .button.type3.type3::before {
                        content: "";
                        display: block;
                        position: absolute;
                        width: 20%;
                        height: 20%;
                        border: 2px solid;
                        transition: all 0.6s ease;
                        border-radius: 2px;
                        }
                        .button.type3.type3::after {
                        bottom: 0;
                        right: 0;
                        border-top-color: transparent;
                        border-left-color: transparent;
                        border-bottom-color: #435a6b;
                        border-right-color: #435a6b;
                        }
                        .button.type3.type3::before {
                        top: 0;
                        left: 0;
                        border-bottom-color: transparent;
                        border-right-color: transparent;
                        border-top-color: #435a6b;
                        border-left-color: #435a6b;
                        }
                        .button.type3.type3:hover:after, .button.type3.type3:hover:before {
                        border-bottom-color: #435a6b;
                        border-right-color: #435a6b;
                        border-top-color: #435a6b;
                        border-left-color: #435a6b;
                        width: 100%;
                        height: 100%;
                        }
                        .button.type4 {
                        color: red;
                        }
                        .button.type4::after {
                        content: "";
                        display: block;
                        position: absolute;
                        height: 2px;
                        width: 0;
                        left: 0;
                        background-color: red;
                        transition: width 0.3s ease-in-out;
                        }
                        .button.type4::after {
                        bottom: 0;
                        }
                        .button.type4:hover::after {
                        width: 50px;
                        }
                        .container1{
                            margin-block: 20px;
                            box-sizing: border-box;
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            flex-direction: column;
                        }




                    #menu {
                        grid-template-columns: repeat(2, auto);
                        /*grid-template-rows: repeat(3, auto);*/
                    }
                    fieldset {
                        border-radius: 20px;
                        width: auto;
                    }
                    #grid {
                        display: grid;
                        grid-template-columns: repeat(2, auto);
                    }
                    #grid2 {
                        display: grid;
                        grid-template-rows: repeat(2, auto);
                        justify-content: center;
                        justify-items: center;
                    }

                    #menu {
                        justify-content: center;
                        border-radius: 20px;
                        width: 100%;
                        background-color: white;
                        margin-block: 10px;
                        height: 120%;
                        grid-template-columns: repeat(3, auto);
                        margin-right: 10px;
                        display: grid;
                        
                    }

                    .enlace {
                        display: grid;

                        align-items: center;
                        width: 120%;
                    }
                    
                    #menus{
                        display: grid;
                        grid-template-columns: 15% auto;
                        /*grid-template-rows: repeat(2, auto);*/
                    }

                    #buscar {
                        display: grid;
                        justify-content: center;
                        border-radius: 20px;
                        width: auto;
                        background-color: white;
                        margin-block: 10px;
                        height: 120%;
                       
                        
                        margin-left: 10px;
                        align-items: center;
                    }

                    input {
                        width: 350px;
                        height: 80px;
                        font-size: 1.2em;
                        padding: 15px 25px;
                        border-radius: 10px;
                        border: none;
                        box-shadow: 0 5px 24px rgb(31 37 59 / 35%);
                        margin: 25px;

                    }

                    #legend{
                        margin: 20px;
                    }

                    a {
                        color: black;
                        text-decoration: none;
                        margin: 20px;
                        width: auto;
                    }

                    @media screen and (max-width: 1650px){
                        #menus{
                            display: grid;
                            grid-template-columns: repeat(1, auto);
                            grid-template-rows: repeat(2, auto);
                        }

                        #menu{
                            
                            margin-right: 0px;
                        }

                        #buscar {
                            margin-left: 0px;
                            margin-top: 60px;
                        }

                        #grid {
                            display: grid;
                            height: auto;
                            justify-items: center;
                            align-items: center;
                        }

                        .container1 {
                            box-sizing: border-box;
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            flex-direction: row;
                        }


                    }    

                    @media screen and (max-width: 1250px){
                        #menus{
                            display: grid;
                            grid-template-columns: repeat(1, auto);
                            grid-template-rows: repeat(2, auto);
                        }

                        #menu{
                            
                            margin-right: 0px;
                        }

                        #buscar {
                            margin-left: 0px;
                            margin-top: 60px;
                            height: 100%;
                        }

                        form {
                            display: grid;
                            justify-content: center;
                            grid-template-columns: repeat(1, auto);
                        }

                        header {
                            display: grid;
                            position: block;
                            height: 75px;
                            width: 100%;
                            background-color: #ead9c7;
                        }
                        #header {
                            height: 75px;
                            width: 100%;
                            margin: 0px;
                            background-color: #ead9c7;
                        }

                        #grid {
                            display: grid;
                            height: auto;
                            justify-items: center;
                            align-items: center;
                        }
                        .container1 {
                            box-sizing: border-box;
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            flex-direction: row;
                        }

                    }  
                    

                    H2 {font-size: 17pt; font-weight: bold; font-style: ; color: black;}

.animacion {
  position: relative;
  animation: mymove 5s ;
  bottom: 200px;
}

.sinanimacion {
  position: relative;
  bottom: 200px;
}

@keyframes mymove {
  from {bottom: 0px;}
  to {bottom: 200px;}
}

                </style>
                <script>

                    /*noSection = document.querySelector("#enviar");
                    sectionLoguin = document.querySelector("#formulario");

                    noSection.addEventListener('click', (e) =>{
                        e.preventDefault();
                        sectionLoguin.classList.remove("sinanimacion");
                        sectionLoguin.classList.add("animacion");
                    });


                    function animacionForm() {
                        document.getElementById("formulario").classList.toggle("animacion");

                    }*/

                    function prueba(){

                        let elementoActivo = document.querySelector('input[name="sizeBy"]:checked');
                        
                        if(elementoActivo) {

                            document.getElementById("añadir").href = "./" + elementoActivo.value + "/añadir";
                            document.getElementById("borrar").href = "./" + elementoActivo.value + "/borrar";
                            document.getElementById("legend").innerHTML = "Buscar " + elementoActivo.value;

                            if (elementoActivo.value == "Pisos") {

                                //alert(elementoActivo.value);
                                //document.getElementsByName("correo")[0].value="";    
                                //document.getElementsByName("correo")[0].placeholder="your message";

                                document.getElementById("correo").placeholder = "Direccion del Piso";
                                document.getElementById("nombre").placeholder = "Codigo Postal";
                                document.getElementById("enviar").name = "enviarPisos";

                            } 

                            if (elementoActivo.value == "Usuarios") {

                                //elementoActivo.value = "Usuarios";
                                //document.getElementsByName("correo")[0].value="";    
                                //document.getElementsByName("correo")[0].placeholder="your message1";

                                document.getElementById("correo").placeholder = "Correo del Usuario";
                                document.getElementById("nombre").placeholder = "Nombre del Usuario";
                                document.getElementById("enviar").name = "enviarUsuarios";
                            }
                            
                        } else {

                            alert('No hay ninún elemento activo');

                        }

                    }

                </script>
            </head>
                <body>
                    <div id="div"></div>
                    <div id="header">
                        <header>
                            <h2>Hola <?php echo strtoupper($_SESSION["nombres"]) ?></h2>
                        </header>
                    </div>
                    <div id="widjets">
                        <div id="cop">
                            <fieldset>
                                <div id="grid2">
                                    <legend>¿Que quieres administrar?</legend>
                                    <div class="toggle">
                                        <div id="grid">
                                            <input type="radio" onclick="prueba()" name="sizeBy" value="Usuarios" id="sizeWeight" checked="checked" />
                                            <label for="sizeWeight">Usuarios</label>
                                            <input type="radio" onclick="prueba()" name="sizeBy" value="Pisos" id="sizeDimensions"/>
                                            <label for="sizeDimensions">Pisos</label>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </div>
                        <div id="menus">
                            <div id= "menu">
                                    <div class="container1">
                                        <a href='./index.php'>
                                            <button class="button type1">
                                                <h2>Login</h2>
                                            </button>
                                        </a>
                                        <a id="añadir" href='./usuarios/Añadir.php'>
                                            <button class="button type3">
                                                <h2>Añadir</h2>
                                            </button>
                                        </a>
                                        <a id="borrar" href='./usuarios/Borrar.php'>
                                            <button class="button type3">
                                                <h2>Borrar</h2>
                                            </button>
                                        </a>
                                    </div>
                            </div>
                            <div id="buscar">
                                <form action="./index.php" method="POST" id="formulario" 
                                <?php 

                                    


                                ?>
                                
                                >
                                        <h2 id="legend">Buscar Usuarios:</h2>
                                        <input id="correo" placeholder="Correo del Usuario" type="text" name="correo" size="40">
                                        <input id="nombre" placeholder="Nombre del Usuario" type="text" name="nombre" size="40">
                                        <input id="enviar" name="enviarUsuarios" type="submit" value="Enviar">

                                        <script>

                                            document.addEventListener('submit', function(event) {
                                                
                                                document.getElementById("formulario").classList.add("animacion");
                                                event.preventDefault(); 
                                                
                                                setTimeout(function() {
                                                
                                                    document.getElementById("formulario").classList.add("sinanimacion");
                                                    document.getElementById("formulario").classList.remove("animacion");

                                                }, 5000);

                                                
                                                setTimeout(function() {

                                                    document.getElementById("formulario").submit();

                                                }, 5000);

                                            });

                                            /*document.addEventListener('submit', function(event) {
                                                document.getElementById("formulario").classList.add("animacion");
                                                event.preventDefault();
                                                setTimeout(function() {
                                                    event.submit();
                                                }, 5000);
                                            });*/

                                        </script>

                                </form>


                                <?php

                                if(isset($_POST["enviarUsuarios"])){

                                    $servername = "localhost";
                                    $username = "root";
                                    $password = "rootroot";
                                    $dbname = "inmobiliaria";

                                    // Crea conexion

                                    $conn = mysqli_connect($servername, $username, $password, $dbname);

                                    // Compruebar errores:

                                    if (!$conn) {

                                        die("Connection failed: " . mysqli_connect_error());

                                    }

                                    // Insertamos los datos del form en variables.

                                    $correo = $_REQUEST["correo"];
                                    $nombre = $_REQUEST["nombre"];

                                    // Query en caso de que las dos esten vacías.

                                    if (($correo == "") && ($nombre == "")) {


                                        $sql = "SELECT usuario_id, nombres, correo, clave FROM usuario;";

                                    }

                                    // Query en caso de que el correo esté vacío.

                                    if (($correo == "") && (isset($nombre))) {

                                        $sql = "SELECT usuario_id, nombres, correo, clave FROM usuario WHERE nombres LIKE '$nombre';";

                                    }

                                    // Query en caso de que el nombre esté vacío.

                                    if (($nombre == "") && (isset($correo))) {

                                        $sql = "SELECT usuario_id, nombres, correo, clave FROM usuario WHERE correo LIKE '$correo';";

                                    }
                                        
                                    // Query en caso de que no haya nada vacío.

                                    if ((isset($nombre)) && (isset($correo))) {

                                        $sql = "SELECT usuario_id, nombres, correo, clave FROM usuario WHERE correo LIKE '$correo' AND nombres LIKE '$nombre';";

                                    }


                                    $sql = "SELECT usuario_id, nombres, correo FROM usuario;";
                                    $result = mysqli_query($conn, $sql); 

                                    //ejecutar la select

                                    
                                    
                                    if (mysqli_num_rows($result) > 0) {

                                    // Muestra los datos fila fila
                                   

                                    ?>
                                    <style>
                                        #resultado {
                                            display: grid;
                                            grid-template-columns: repeat(3, auto);
                                            position: relative;
                                        }
                                    </style>
                                    <div id="resultado">
                                    <?php while($row = mysqli_fetch_assoc($result)) { ?>
                                        <div><?php echo  $row['usuario_id']; ?></div>
                                        <div><?php echo  $row['nombres']; ?></div>
                                        <div><?php echo  $row['correo']; ?></div>
                                        <div><?php echo  $row['clave']; ?></div>
                                    <?php } ?>
                                    </div>


                                    <?php


                                      /*   ?>
                                        
                                        <table>
                                        <?php
                                        while($row = mysqli_fetch_assoc($result)) {
                                            ?>
                                            <tr>
                                            <td><b>ID </b></td> <td><?php echo  $row['usuario_id']; ?></td>
                                            <td><b>Nombre </b></td><td><?php echo $row["nombres"]; ?></td>
                                            <td><b>Correo </b></td><td><?php echo $row["correo"]; ?></td>
                                            </tr>
                                            
                                            
                                            <?php

                                        }

                                        ?>
                                        </table>
                                        <?php
                                    */

                                    } else {

                                        echo "No hay datos";

                                    }

                                    mysqli_close($conn);

                                    }




?>
                            </div>
                        </div>
                    </div>
                </body>


     
        
