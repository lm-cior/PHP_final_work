CREATE TABLE usuario (
    usuario_id int(5) NOT NULL primary key AUTO_INCREMENT,
    nombres varchar(35) NOT NULL,
    correo varchar(100) NOT NULL,
    clave varchar(80) NOT NULL,
    tipo_usuario varchar(20)
 );

CREATE TABLE pisos (
    Codigo_piso int primary key AUTO_INCREMENT,
    calle VARCHAR(40) NOT NULL,
    numero INT NOT NULL,
    piso INT,
    puerta VARCHAR(5),
    cp INT NOT NULL,
    metros INT NOT NULL,
    zona VARCHAR (15),
    precio float NOT NULL,
    imagen varchar(100) NOT NULL,
    usuario_id int(5)references usuario
);

CREATE TABLE comprados (
    usuario_comprador int(5)references usuario(usuario_id),
    Codigo_piso int references pisos,
    Precio_final float NOT NULL
 );

INSERT INTO pisos values(00,'Calle del Escritor', 9, 4,'2A',19171,250,'mostoles',250,'160223',7);
INSERT INTO pisos values(00,'Calle del Escritor', 9, 4,'2A',19171,250,'mostoles',250,'170223',7);
INSERT INTO pisos values(00,'Calle del Escritor', 9, 4,'2A',19171,250,'mostoles',250,'182023',7);
INSERT INTO pisos values(00,'Calle del Escritor', 9, 4,'2A',19171,250,'mostoles',250,'190223',7);
