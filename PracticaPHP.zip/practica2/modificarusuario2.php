<?php 
session_start();
$id=$_SESSION["id"];
    if(isset($_REQUEST["modifUser"])){

        $servername = "localhost";
        $username = "root";
        $password = "rootroot";
        $dbname = "inmobiliaria";

    // Crea conexion

        $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Comprueba:

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        } 

            $passwd = trim(strtolower($_POST["acontraseña"]));
            $mnombres = trim(strtolower($_POST["mnombres"]));
            $mcorreo = trim(strtolower($_POST["mcorreo"]));

            $password=password_hash("$passwd", PASSWORD_DEFAULT);

            if ($passwd == ""){
                $sql = "UPDATE usuario SET nombres='$mnombres', correo='$mcorreo' WHERE usuario_id=$id;";
            } else {
                $sql = "UPDATE usuario SET nombres='$mnombres', correo='$mcorreo', clave='$password' WHERE usuario_id=$id;";
            }

        
        echo "<BR>$sql<BR>";

    /*UPDATE usuario SET nombres='jota', correo='jota@gmail.com' WHERE usuario_id=2;*/
            
        if (mysqli_query($conn, $sql)) {

            echo "Record updated successfully";
            header("location:./index.php");
            $_SESSION["mbusc"] = "";


        } else {

            echo "Error updating record: " . mysqli_error($conn);

        }
        mysqli_close($conn);
            

    } else {

        echo "hola";   

    }